=== Tuxquote ===
Contributors: eldougo
Donate link: 
Tags: quote, tux
Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show a random image of Tux the Linux penguin with a random quote.

== Description ==

Tuxquote show a random image of Tux the Linux penguin with a random quote using the '[TUXQUOTE]' shortcode.

You can add or remove images from wp-content/plugins/tuxquote/images/ directory. All jpg, png and gif images will be randomly used from that directory.

Add or remove quotes from the wp-content/plugins/tuxquote/quotes.txt file. Quotes are line delimited and HTML formatting can be used, enabling you to use <br /> for line breaks etc.

Development for this plugin can now be found on GitHub: https://github.com/eldougo/wordpress_plugin_tuxquote

== Installation ==

Upload the Tuxquote plugin to your blog, activate it, then enter the shortcode '[TUXQUOITE]' in your page or post.

== Frequently Asked Questions ==

== Screenshots ==

1. Tuxquote in action - static sample only.
2. Tuxquote in action - static sample only.

== Changelog ==

= 0.1 =
Initial.


